package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.CustomerServiceImplementation;
import service.SubscriptionServiceImplementation;
import bean.Customer;
import bean.Subscription;

@WebServlet("/SubscriptionController")
public class SubscriptionController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		String operation = request.getParameter("operation");
		if(operation.equals("addplan"))
		{
			String op=request.getParameter("content");
			System.out.println(operation);
			System.out.println(op);
			
			int addplan=Integer.parseInt(op);
			System.out.println(addplan);

			HttpSession session = request.getSession();
			String uname=""+session.getAttribute("username");
			request.setAttribute("content", addplan);
			
			Customer c=new Customer();
			c.setCust_name(uname);
			CustomerServiceImplementation customerservice=new CustomerServiceImplementation();
			int cust_id=customerservice.getCust_id(c);
			System.out.println(cust_id);	
			int plan_id=addplan;
			
			Subscription addSubscriber=new Subscription();
			addSubscriber.setSub_cust_id(cust_id);
			addSubscriber.setSub_plan_id(plan_id);
			SubscriptionServiceImplementation service=new SubscriptionServiceImplementation();
			boolean status = service.addSubscription(addSubscriber);
			request.setAttribute("subscriptionstatus", status);
			request.getRequestDispatcher("plandetails_subscribed.jsp").include(request, response);
			//response.sendRedirect("plandetails.jsp");
		}
			
		if(operation.equals("subscriptiondetails"))
		{
			System.out.println("In Subscription");
			HttpSession session = request.getSession();
			String uname=""+session.getAttribute("username");
			Customer c=new Customer();
			c.setCust_name(uname);
			CustomerServiceImplementation customerservice=new CustomerServiceImplementation();
			int cust_id=customerservice.getCust_id(c);
			Subscription showSubscriber=new Subscription();
			
			showSubscriber.setSub_cust_id(cust_id);
			
			request.setAttribute("operation", operation);
			SubscriptionServiceImplementation service=new SubscriptionServiceImplementation();
			ArrayList<Subscription> sub = service.getAllSubscriptions(showSubscriber);
			request.setAttribute("subscription", sub);
			request.getRequestDispatcher("mysubscription_details.jsp").include(request, response);
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
