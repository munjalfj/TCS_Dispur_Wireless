package controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.CustomerServiceImplementation;
import service.SubscriptionServiceImplementation;
import bean.Customer;
import bean.Subscription;

@WebServlet("/SubscriptionController")
public class SubscriptionController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		String operation = request.getParameter("operation");
		System.out.println(operation);
		if(operation.equals("addplan"))
		{
			String op=request.getParameter("content");
			System.out.println(operation);
			System.out.println(op);
			
			int addplan=Integer.parseInt(op);
			System.out.println(addplan);

			HttpSession session = request.getSession();
			String uname=""+session.getAttribute("username");
			request.setAttribute("content", addplan);
			
			Customer c=new Customer();
			c.setCust_name(uname);
			CustomerServiceImplementation customerservice=new CustomerServiceImplementation();
			int cust_id=customerservice.getCust_id(c);
			System.out.println(cust_id);	
			int plan_id=addplan;
			
			Subscription addSubscriber=new Subscription();
			addSubscriber.setSub_cust_id(cust_id);
			addSubscriber.setSub_plan_id(plan_id);
			SubscriptionServiceImplementation service=new SubscriptionServiceImplementation();
			boolean status = service.addSubscription(addSubscriber);
			request.setAttribute("subscriptionstatus", status);
			request.getRequestDispatcher("plandetails_subscribed.jsp").include(request, response);
			//response.sendRedirect("plandetails.jsp");
		}
			
		if(operation.equals("subscriptiondetails"))
		{
			System.out.println("In Subscription");
			HttpSession session = request.getSession();
			String uname=""+session.getAttribute("username");
			Customer c=new Customer();
			c.setCust_name(uname);
			CustomerServiceImplementation customerservice=new CustomerServiceImplementation();
			int cust_id=customerservice.getCust_id(c);
			Subscription showSubscriber=new Subscription();
			
			showSubscriber.setSub_cust_id(cust_id);
			
			request.setAttribute("operation", operation);
			SubscriptionServiceImplementation service=new SubscriptionServiceImplementation();
			ArrayList<Subscription> sub = service.getAllSubscriptions(showSubscriber);
			request.setAttribute("subscription", sub);
			request.getRequestDispatcher("mysubscription_details.jsp").include(request, response);
		}
		
		if(operation.equals("canclesubscription"))
		{
			String val=request.getParameter("val");
			int plan_id=Integer.parseInt(val);
			System.out.println(plan_id);
			Subscription canclesubscription=new Subscription();
			canclesubscription.setSub_plan_id(plan_id);
			SubscriptionServiceImplementation servicetime=new SubscriptionServiceImplementation();
			Date date = new Date();
			Timestamp log_timestamp = new Timestamp(date.getTime());
			canclesubscription=servicetime.checkcanclesubscription(canclesubscription);
			
//			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.s");
//			sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
//			String temp=""+canclesubscription.getSub_timestamp();
//		   // java.util.Date startDate =  sdf.parse(canclesubscription.getSub_timestamp());
//		    java.util.Date endDate=new java.util.Date();  	
//		    int m1 = startDate.getYear() * 12 + startDate.getMonth();
//		    int m2 = endDate.getYear() * 12 + endDate.getMonth();
//		    int diff_in_months =  m2 - m1 + 1;
		    
		    long timestamp1 = canclesubscription.getSub_timestamp().getTime();
		    Calendar cal1 = Calendar.getInstance();
		    cal1.setTimeInMillis(timestamp1);
		    int oldmonth=cal1.get(Calendar.MONTH);
		    System.out.println(oldmonth);
		    long timestamp = log_timestamp.getTime();
		    Calendar cal2 = Calendar.getInstance();
		    cal2.setTimeInMillis(timestamp);
		    int currentmonth=cal2.get(Calendar.MONTH);
		    System.out.println(currentmonth);
//
		    
////		SubscriptionServiceImplementation service=new SubscriptionServiceImplementation();
//			int status=service.cancleSubscription(canclesubscription);
//			request.setAttribute("subscription", status);
//			request.getRequestDispatcher("deleteconfirmation.jsp").include(request, response);

			if(currentmonth>oldmonth)
			{
				if(currentmonth-oldmonth>=3)
				{
					SubscriptionServiceImplementation service=new SubscriptionServiceImplementation();
					int status=service.cancleSubscription(canclesubscription);
					request.setAttribute("subscription", status);
					request.getRequestDispatcher("deleteconfirmation.jsp").include(request, response);
					
				}
			}
			else if(currentmonth<oldmonth)
			{
				if((currentmonth+12)-oldmonth>=3)
				{
					SubscriptionServiceImplementation service=new SubscriptionServiceImplementation();
					int status=service.cancleSubscription(canclesubscription);
					request.setAttribute("subscription", status);
					request.getRequestDispatcher("deleteconfirmation.jsp").include(request, response);
					
				}
			}
			else
			{
				String status="false";
				request.setAttribute("subscription",status);
				request.getRequestDispatcher("deletefailed.jsp").include(request, response);
			}
			
		}
		
		if(operation.equals("changesubscription"))
		{
			String oldval=request.getParameter("oldval");
			String newval=request.getParameter("newval");
			int old_plan_id=Integer.parseInt(oldval);
			int new_plan_id=Integer.parseInt(newval);
			Subscription s1=new Subscription();
			s1.setSub_plan_id(old_plan_id);
			Subscription s2=new Subscription();
			s2.setSub_plan_id(new_plan_id);
			SubscriptionServiceImplementation servicetime=new SubscriptionServiceImplementation();
			
			request.setAttribute("operation", operation);
			SubscriptionServiceImplementation service=new SubscriptionServiceImplementation();
			int status=service.updateSubscription(s1,s2);
			request.setAttribute("subscription", status);
			request.getRequestDispatcher("changesuccessfull.jsp").include(request, response);
		}
		
		if(operation.equals("subscriptiondetails"))
		{
			System.out.println("In Subscription");
			HttpSession session = request.getSession();
			String uname=""+session.getAttribute("username");
			Customer c=new Customer();
			c.setCust_name(uname);
			CustomerServiceImplementation customerservice=new CustomerServiceImplementation();
			int cust_id=customerservice.getCust_id(c);
			Subscription showSubscriber=new Subscription();
			
			showSubscriber.setSub_cust_id(cust_id);
			
			request.setAttribute("operation", operation);
			SubscriptionServiceImplementation service=new SubscriptionServiceImplementation();
			ArrayList<Subscription> sub = service.getAllSubscriptions(showSubscriber);
			request.setAttribute("subscription", sub);
			request.getRequestDispatcher("mysubscription_details.jsp").include(request, response);
		}
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
