package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.PlanServiceImplementation;
import bean.Plan;

@WebServlet("/PlanController")
public class PlanController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String operation = request.getParameter("operation");
		System.out.println(operation);
		if(operation.equals("plandetails"))
		{
			request.setAttribute("operation", operation);
			PlanServiceImplementation service=new PlanServiceImplementation();
			ArrayList<Plan> plan = service.getAllPlans();
			request.setAttribute("plan", plan);
			request.getRequestDispatcher("plandetails.jsp").include(request, response);
		}
		
		if(operation.equals("changeplandetails"))
		{
			String val=request.getParameter("val");
			request.setAttribute("operation", operation);
			PlanServiceImplementation service=new PlanServiceImplementation();
			ArrayList<Plan> plan = service.getAllPlans();
			request.setAttribute("plan", plan);
			request.setAttribute("val", val);
			request.getRequestDispatcher("changeselectplan.jsp").include(request, response);
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
