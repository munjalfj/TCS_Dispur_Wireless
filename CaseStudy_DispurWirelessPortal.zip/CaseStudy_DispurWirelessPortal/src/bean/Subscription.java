package bean;

import java.sql.Timestamp;

public class Subscription 
{
	int sub_cust_id;
	int sub_plan_id;
	Timestamp sub_timestamp;
	
	public int getSub_cust_id() {
		return sub_cust_id;
	}
	public void setSub_cust_id(int sub_cust_id) {
		this.sub_cust_id = sub_cust_id;
	}
	public int getSub_plan_id() {
		return sub_plan_id;
	}
	public void setSub_plan_id(int sub_plan_id) {
		this.sub_plan_id = sub_plan_id;
	}
	public Timestamp getSub_timestamp() {
		return sub_timestamp;
	}
	public void setSub_timestamp(Timestamp sub_timestamp) {
		this.sub_timestamp = sub_timestamp;
	}
	
}
