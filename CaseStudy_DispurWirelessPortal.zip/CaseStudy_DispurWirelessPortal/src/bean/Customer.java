package bean;

public class Customer 
{
	int cust_id;
	String cust_name;
	String cust_address;
	String cust_email;
	int cust_cno;
	public int getCust_id() {
		return cust_id;
	}
	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getCust_address() {
		return cust_address;
	}
	public void setCust_address(String cust_address) {
		this.cust_address = cust_address;
	}
	public String getCust_email() {
		return cust_email;
	}
	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}
	public int getCust_cno() {
		return cust_cno;
	}
	public void setCust_cno(int cust_cno) {
		this.cust_cno = cust_cno;
	}
}
