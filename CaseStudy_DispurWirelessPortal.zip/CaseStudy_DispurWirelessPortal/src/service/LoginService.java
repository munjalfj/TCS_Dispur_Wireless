package service;

import bean.Login;

public interface LoginService 
{
	public boolean check(Login l);
}