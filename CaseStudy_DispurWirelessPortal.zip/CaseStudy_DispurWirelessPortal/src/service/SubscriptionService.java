package service;

import java.util.ArrayList;

import bean.Subscription;


public interface SubscriptionService 
{
	public ArrayList<Subscription> getAllSubscriptions(Subscription s);
	public boolean addSubscription(Subscription s);
	public int cancleSubscription(Subscription s);
	public Subscription checkcanclesubscription(Subscription s);
	public int updateSubscription(Subscription s1,Subscription s2);
}
