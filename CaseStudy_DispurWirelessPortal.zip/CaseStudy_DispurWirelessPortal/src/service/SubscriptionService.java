package service;

import java.util.ArrayList;

import bean.Subscription;


public interface SubscriptionService 
{
	public ArrayList<Subscription> getAllSubscriptions(Subscription s);
	public boolean addSubscription(Subscription s);
}
