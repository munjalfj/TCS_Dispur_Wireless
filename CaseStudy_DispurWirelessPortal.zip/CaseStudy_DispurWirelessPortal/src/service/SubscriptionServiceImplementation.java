package service;

import java.util.ArrayList;

import bean.Subscription;
import dao.SubscriptionDao;




public class SubscriptionServiceImplementation implements SubscriptionService
{	@Override
	public ArrayList<Subscription> getAllSubscriptions(Subscription s) 
	{
		return SubscriptionDao.getAllSubscriptions(s);
	}

	@Override
	public boolean addSubscription(Subscription s)
	{
		return SubscriptionDao.addSubscription(s);
	}
	
	@Override
	public int cancleSubscription(Subscription s)
	{
		return SubscriptionDao.cancleSubscription(s);
	}
	
	@Override
	public Subscription checkcanclesubscription(Subscription s)
	{
		return SubscriptionDao.getSubscribedTime(s);
	}

	@Override
	public int updateSubscription(Subscription s1,Subscription s2)
	{
		return SubscriptionDao.updateSubscription(s1,s2);
	}
}
