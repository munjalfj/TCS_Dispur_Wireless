package service;

import java.util.ArrayList;

import bean.Subscription;
import dao.SubscriptionDao;




public class SubscriptionServiceImplementation implements SubscriptionService
{	@Override
	public ArrayList<Subscription> getAllSubscriptions(Subscription s) 
	{
		return SubscriptionDao.getAllSubscriptions(s);
	}

	@Override
	public boolean addSubscription(Subscription s)
	{
		return SubscriptionDao.addSubscription(s);
	}

}
