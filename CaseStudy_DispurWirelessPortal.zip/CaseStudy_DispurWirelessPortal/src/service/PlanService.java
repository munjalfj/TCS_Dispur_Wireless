package service;

import java.util.ArrayList;

import bean.Plan;

public interface PlanService 
{
	public Plan getplandetails(Plan p);
	public ArrayList<Plan> getAllPlans();
	public Plan getplan(Plan a);
}
