package service;

import java.util.ArrayList;

import bean.Customer;
import bean.Plan;
import dao.CustomerDao;
import dao.PlanDao;

public class CustomerServiceImplementation implements CustomerService
{
	@Override
	public int getCust_id(Customer c)
	{
		int id=CustomerDao.getCustId(c);
		return id;
	}
	
	@Override
	public ArrayList<Customer> getAllCustomers()
	{
		return CustomerDao.getAllCustomers();
	}
	
	@Override
	public Customer getCustomer(Customer a)
	{
		return CustomerDao.getCustomerDetails(a);
	}
}
