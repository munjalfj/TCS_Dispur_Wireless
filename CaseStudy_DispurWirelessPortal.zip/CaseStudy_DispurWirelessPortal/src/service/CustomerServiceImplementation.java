package service;

import bean.Customer;
import dao.CustomerDao;

public class CustomerServiceImplementation implements CustomerService
{
	@Override
	public int getCust_id(Customer c)
	{
		int id=CustomerDao.getCustId(c);
		return id;
	}
}
