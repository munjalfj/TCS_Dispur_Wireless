package service;

import bean.Customer;

public interface CustomerService 
{
	public int getCust_id(Customer c);
}
