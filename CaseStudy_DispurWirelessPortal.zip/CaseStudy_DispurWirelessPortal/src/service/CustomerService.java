package service;

import java.util.ArrayList;

import bean.Customer;
import bean.Plan;

public interface CustomerService 
{
	public int getCust_id(Customer c);
	public ArrayList<Customer> getAllCustomers();
	public Customer getCustomer(Customer a);
}
