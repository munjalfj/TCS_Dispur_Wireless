package service;

import java.util.ArrayList;

import bean.Plan;
import dao.PlanDao;

public class PlanServiceImplementation implements PlanService
{
	@Override
	public Plan getplandetails(Plan a) 
	{
		PlanServiceImplementation service = new PlanServiceImplementation();
		Plan details = service.getplandetails(a);
		return details;
	}
	
	@Override
	public ArrayList<Plan> getAllPlans() 
	{
		return PlanDao.getAllPlans();
	}
	
	@Override
	public Plan getplan(Plan a)
	{
		return PlanDao.getPlanDetails(a);
	}
}
