package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import bean.Customer;
import database.DatabaseConnection;

public class CustomerDao 
{
	public static int getCustId(Customer c) 
	{
		try
		{
			Connection con = DatabaseConnection.getConnection();
			PreparedStatement ps = con.prepareStatement("select cust_id from customer where cust_name= ?");
			ps.setString(1, c.getCust_name());
			
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				c.setCust_id(rs.getInt(1));
			}
			
			con.close();
		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
		}
		
		return c.getCust_id();
	}
	
}
