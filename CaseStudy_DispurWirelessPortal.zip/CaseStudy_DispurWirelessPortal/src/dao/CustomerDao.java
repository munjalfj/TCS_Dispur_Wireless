package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Customer;
import bean.Plan;
import database.DatabaseConnection;

public class CustomerDao 
{
	public static int getCustId(Customer c) 
	{
		try
		{
			Connection con = DatabaseConnection.getConnection();
			PreparedStatement ps = con.prepareStatement("select cust_id from customer where cust_name= ?");
			ps.setString(1, c.getCust_name());
			
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				c.setCust_id(rs.getInt(1));
			}
			
			con.close();
		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
		}
		
		return c.getCust_id();
	}
	
	
	public static ArrayList<Customer> getAllCustomers() {
		ArrayList<Customer> customer = new ArrayList<>();
		try {
			Connection con = DatabaseConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from customer");
			while (rs.next()) {
				Customer a = new Customer();
				a.setCust_id(rs.getInt(1));
				a.setCust_name(rs.getString(2));
				a.setCust_address(rs.getString(3));
				a.setCust_email(rs.getString(4));
				a.setCust_cno(rs.getInt(5));
				customer.add(a);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return customer;
	}
	
	public static Customer getCustomerDetails(Customer a) {
		try {
			Connection con = DatabaseConnection.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from customer where cust_id = ?");
			ps.setLong(1, a.getCust_id());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				a.setCust_id(rs.getInt(1));
				a.setCust_name(rs.getString(2));
				a.setCust_address(rs.getString(3));
				a.setCust_email(rs.getString(4));
				a.setCust_cno(rs.getInt(5));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return a;
	}
	
}
