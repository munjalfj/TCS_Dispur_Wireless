package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Subscription;
import database.DatabaseConnection;

public class SubscriptionDao 
{
	public static ArrayList<Subscription> getAllSubscriptions(Subscription s) 
	{
		ArrayList<Subscription> subscription = new ArrayList<>();
		try {
			int cid=s.getSub_cust_id();
			Connection con = DatabaseConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from subscription where sub_cust_id="+cid);
			while (rs.next()) 
			{
				Subscription a = new Subscription();
				a.setSub_cust_id(rs.getInt(1));
				a.setSub_plan_id(rs.getInt(2));
				a.setSub_timestamp(rs.getTimestamp(3));
				subscription.add(a);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return subscription;
	}
	
	public static boolean addSubscription(Subscription l)
	{
		try
		{
			Connection con = DatabaseConnection.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into subscription (sub_cust_id,sub_plan_id) values(?, ?)");

			ps.setLong(1,l.getSub_cust_id() );
			ps.setLong(2,l.getSub_plan_id());;

			int status = ps.executeUpdate();
			if(status == 1)
			{
				return true;
			}
			con.close();
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		return false;
		}
			
	}
