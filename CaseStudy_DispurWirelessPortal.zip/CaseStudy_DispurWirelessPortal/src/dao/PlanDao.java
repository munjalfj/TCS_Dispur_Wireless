package dao;

import java.sql.*;
import java.util.ArrayList;
import bean.Plan;
import database.DatabaseConnection;

public class PlanDao 
{
	public static ArrayList<Plan> getAllPlans() {
		ArrayList<Plan> plan = new ArrayList<>();
		try {
			Connection con = DatabaseConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from plan");
			while (rs.next()) {
				Plan a = new Plan();
				a.setPlan_id(rs.getInt(1));
				a.setPlan_name(rs.getString(2));
				a.setPlan_type(rs.getString(3));
				a.setPlan_tarrif(rs.getInt(4));
				a.setPlan_validity(rs.getInt(5));
				a.setPlan_rental(rs.getInt(6));
				plan.add(a);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return plan;
	}
	
	
	public static Plan getPlanDetails(Plan a) {
		try {
			Connection con = DatabaseConnection.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from plan where plan_id = ?");
			ps.setLong(1, a.getPlan_id());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				a.setPlan_id(rs.getInt(1));
				a.setPlan_name(rs.getString(2));
				a.setPlan_type(rs.getString(3));
				a.setPlan_tarrif(rs.getInt(4));
				a.setPlan_validity(rs.getInt(5));
				a.setPlan_rental(rs.getInt(6));
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return a;
	}

}
