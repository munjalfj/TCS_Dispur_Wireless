# TCS_Bank Case Study

This is the Web App for Bank.
