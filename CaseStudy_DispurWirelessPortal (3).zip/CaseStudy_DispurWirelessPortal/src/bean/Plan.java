package bean;

public class Plan {

}
