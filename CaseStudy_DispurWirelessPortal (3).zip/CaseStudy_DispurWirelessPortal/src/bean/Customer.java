package bean;

public class Customer {

}
