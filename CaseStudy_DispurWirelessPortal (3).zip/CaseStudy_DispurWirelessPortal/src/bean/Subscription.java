package bean;

public class Subscription {

}
