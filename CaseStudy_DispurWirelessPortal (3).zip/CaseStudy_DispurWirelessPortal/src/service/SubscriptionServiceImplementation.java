package service;

public class SubscriptionServiceImplementation {

}
