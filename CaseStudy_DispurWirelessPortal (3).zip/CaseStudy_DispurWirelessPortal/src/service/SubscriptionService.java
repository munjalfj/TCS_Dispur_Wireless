package service;

public class SubscriptionService {

}
