package dao;

public class PlanDao 
{

}
