package dao;

public class CustomerDao {

}
