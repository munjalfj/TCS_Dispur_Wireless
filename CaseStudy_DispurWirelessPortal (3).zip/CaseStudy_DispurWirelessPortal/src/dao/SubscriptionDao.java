package dao;

public class SubscriptionDao {

}
